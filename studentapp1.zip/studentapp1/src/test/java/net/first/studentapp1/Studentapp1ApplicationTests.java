package net.first.studentapp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Studentapp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
