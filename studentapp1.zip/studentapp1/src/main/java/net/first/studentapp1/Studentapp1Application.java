package net.first.studentapp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Studentapp1Application {

	public static void main(String[] args) {
		SpringApplication.run(Studentapp1Application.class, args);
	}

}
