package org.kalpesh.student_app3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentApp3Application {

	public static void main(String[] args) {
		SpringApplication.run(StudentApp3Application.class, args);
	}

}
