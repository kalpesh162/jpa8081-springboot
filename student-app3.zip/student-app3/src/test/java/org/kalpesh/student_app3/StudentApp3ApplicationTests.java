package org.kalpesh.student_app3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentApp3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
