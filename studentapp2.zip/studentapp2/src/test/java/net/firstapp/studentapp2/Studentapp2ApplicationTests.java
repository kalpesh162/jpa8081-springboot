package net.firstapp.studentapp2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Studentapp2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
